<?php
if(!defined('PROTECT'))exit;
if($group_session == GROUP_ADMIN){
$result = 0;
if(isset($_POST['user']) && isset($_POST['action']) && !empty($_POST['user']) && !empty($_POST['action'])){

	$post_name 		= 			addslashes($_POST['user']);
	$post_action 	= 			addslashes($_POST['action']);

	$user_action   = new User($post_name);
	if($post_action == 'addvip'){
		$days 	= 	addslashes($_POST['days']);
		$user_action->addDaysVIP($days, $post_name);
    $user_action->addReport($user_name, $post_name, 'VIP', $days." days added.");
    if($Xenforo->userGroupID($post_name) == GROUP_FREE || $Xenforo->userGroupID($post_name) == GROUP_EXVIP){
      $Xenforo->setUserGroup($post_name, GROUP_VIP);
    }
      $result = 1;
	}
	if($post_action == 'subvip'){
		$days 	= 	addslashes($_POST['days']);
		$user_action->subDaysVIP($days);
    $user_action->addReport($user_name, $post_name, 'VIP', $days." days removed.");
    $result = 2;
	}
  if($post_action == 'ban'){
    $user_action->banHWID();
    $user_action->addReport($user_name, $post_name, 'HWID', "HWID banned.");
    $result = 3;
  }
  if($post_action == 'unban'){
    $user_action->unbanHWID();
     $user_action->addReport($user_name, $post_name, 'HWID', "HWID unbanned.");
    $result = 4;
  }
  if($post_action == 'reset'){
    $user_action->resetHWID();
    $user_action->addReport($user_name, $post_name, 'HWID', "HWID reseted.");
    $result = 5;
  }
  unset($user_action);
}

if(isset($_POST['user']) && isset($_POST['seller']) && isset($_POST['action-active']) && !empty($_POST['user']) && !empty($_POST['seller']) && !empty($_POST['action-active'])){
    $post_name   = addslashes($_POST['user']);
    $user_action = new User($post_name);
    $days   =    addslashes($_POST['days']);
    $seller =    addslashes($_POST['seller']);
    $user_action->addDaysVIP($days, $post_name);
    unset($user_action);
    $user_action = new User($post_name);
    $user_action->activeVIP($days, $seller);
    $user_action->addReport($user_name, $post_name, 'VIP', "VIP ".$days." days activated.");
    if($Xenforo->userGroupID($post_name) == GROUP_FREE || $Xenforo->userGroupID($post_name) == GROUP_EXVIP){
      $Xenforo->setUserGroup($post_name, GROUP_VIP);
    }
    $result = 8;
    unset($user_action);
}

if(isset($_POST['actionall']) && !empty($_POST['actionall'])){
  $post_name    =       addslashes($_POST['user']);
  $user_action = new User();
 if(addslashes($_POST['actionall']) == 'addvipall'){
    $user_action->addDaysVIPALL(addslashes($_POST['days-all']));
    $result = 6;
  }
  if(addslashes($_POST['actionall']) == 'subvipall'){
    $user_action->subDaysVIPALL(addslashes($_POST['days-all']));
    $result = 7;
  }
  unset($user_action);
}
?>

    <div class="row">
  <div class="col-md-12">
        <div class="block-flat">
            <div class="header">
                <h3>Manage Members</h3>
            <div class="content">
                <div class="table-responsive">
                    <table class="table table-bordered" id="datatable">
                        <thead>
                            <tr>
                                <th>Name</th>
								                <th>Days</th>
                                <th>Expire Days</th>
                                <th>Hwid</th>
                                <th>Last Reset</th>
                                <th>Buys</th>
                                <th>Status</th>
								                <th>Last IP</th>
								                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
					                $p_sql = Connection::getInstance()->prepare("SELECT * FROM sys_users WHERE user_expire > NOW()");
						              $p_sql->execute();
                          $user_info = new User();

                          while($row = $p_sql->fetch(PDO::FETCH_ASSOC))
                          {
								            if($row['user_status'] == 'ACTIVE')
									            $status = '<td class="text-center"><span class="label label-success">Active</span>';
								            else
									             $status = '<td class="text-center"><span class="label label-danger">Banned</span>';

							              $user_days = $user_info->getDays($row['user_expire']);
                            $user_buys = $user_info->getUserBuys($row['user_name']);
                          ?>
							                <tr>
								              <td><?php echo $row['user_name']; ?></td>
								              <td><?php echo $user_days; ?></td>
								              <td><?php echo $row['user_expire']; ?></td>
								              <td><?php echo $row['user_hwid']; ?></td>
                              <td><?php echo $row['user_reseted_hwid']; ?></td>
                              <td><?php echo $user_buys; ?></td>
								              <?php echo $status; ?></td>
								              <td><?php echo $row['user_lastip']; ?></td>
								              <td class="text-center"><button name="edit" class="btn btn-primary btn-xs btn-flat md-trigger" data-modal="form-primary"><i class="fa fa-cogs"></i></button></td>
								              </tr>
                          <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
	</div>
        <div class="col-sm-6 col-md-6">
        <div class="block-flat">
          <div class="header">
            <h3>Edit Member</h3>
          </div>
          <div class="content">
            <form id="edit-member" class="form-horizontal" role="form" action="index.php?page=manage_members" method="post">
              <div class="form-group">
              <label for="nick" class="col-sm-2 control-label">Nick</label>
              <div id="editmember" class="col-sm-8">
                <input type="hidden" id="action" name="action" value="null">
                <input name="user" type="text" class="form-control" id="nick" placeholder="">
              </div>
              </div>
              <div class="form-group">
			  <label for="hwid" class="col-sm-2 control-label">Hwid</label>
			   <div class="col-sm-8">
                  <div class="input-group">
                    <input id="hwid"  disabled="disabled" type="text" class="form-control">
                    <div class="input-group-btn">
                    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">Action <span class="caret"></span></button>
                    <ul class="dropdown-menu pull-right">
                      <li><a onclick=" $('#action').val('ban');   $('#edit-member').submit();">Ban</a></li>
                      <li><a onclick=" $('#action').val('unban'); $('#edit-member').submit();">Unban</a></li>
                      <li><a onclick=" $('#action').val('reset'); $('#edit-member').submit();">Reset</a></li>
                    </ul>
                    </div>
                  </div>
					</div>
          </div>
			   <div class="form-group">
			  <label for="vip" class="col-sm-2 control-label">Days</label>
			   <div class="col-sm-8">
                  <div class="input-group">
                    <input name="days" type="text" class="form-control">
                    <div class="input-group-btn">
                    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">Action <span class="caret"></span></button>
                    <ul class="dropdown-menu pull-right">
                      <li><a onclick="$('#action').val('addvip'); $('#edit-member').submit();">Add</a></li>
                      <li><a onclick="$('#action').val('subvip'); $('#edit-member').submit();">Sub</a></li>
                    </ul>
                    </div>
                  </div>
					      </div>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-6">
        <div class="block-flat">
          <div class="header">
            <h3>Activation VIP</h3>
          </div>
          <div class="content">
            <form id="active-vip" class="form-horizontal" role="form" action="index.php?page=manage_members" method="post">
              <div class="form-group">
              <label for="nick" class="col-sm-2 control-label">Nick</label>
              <div id="active-vip" class="col-sm-8">
                <input type="hidden" id="action-active" name="action-active" value="null">
                <input name="user" type="text" class="form-control" id="nick" placeholder="">
              </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Seller</label>
                <div class="col-sm-10">
                  <select name="seller" class="form-control">
                   <option>Seller</option>
                   <option>PayPal</option>
                   <option>Seller 01</option>
                  </select>
                </div>
              </div>
            <div class="form-group">
              <label for="seller" class="col-sm-2 control-label">Seller</label>
              <div id="seller" class="col-sm-8">
                <input name="seller" type="text" class="form-control" id="nick" placeholder="">
              </div>
              </div>
          <div class="form-group">
        <label for="vip" class="col-sm-2 control-label">Days</label>
         <div class="col-sm-8">
                  <div class="input-group">
                    <input name="days" type="text" class="form-control">
                    <div class="input-group-btn">
                    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">Action <span class="caret"></span></button>
                    <ul class="dropdown-menu pull-right">
                      <li><a onclick="$('#action-active').val('activevip'); $('#active-vip').submit();">Active VIP</a></li>
                    </ul>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
        <div class="col-sm-6 col-md-6">
        <div class="block-flat">
          <div class="header">
            <h3>Edit All Members</h3>
          </div>
          <div class="content">
            <form  id="edit-all-member" class="form-horizontal" role="form" action="index.php?page=manage_members" method="post">
			   <div class="form-group">
			  <label for="hwid" class="col-sm-2 control-label">Days</label>
			   <div class="col-sm-8">
                  <div class="input-group">
                    <input name="days-all" id="days-all" type="text" class="form-control">
                    <input type="hidden" id="actionall" name="actionall" value="null">
                    <div class="input-group-btn">
                    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">Action <span class="caret"></span></button>
                    <ul class="dropdown-menu pull-right">
                      <li><a onclick="$('#actionall').val('addvipall'); $('#edit-all-member').submit();">Add</a></li>
                      <li><a onclick="$('#actionall').val('subvipall'); $('#edit-all-member').submit();">Sub</a></li>
                    </ul>
                    </div>
                  </div>
					</div>
              </div>
            </form>
          </div>
        </div>
      </div>
	</div>

  <?php require_once("./templates/script.php"); ?>
  <script type="text/javascript" src="js/jquery.datatables/jquery.datatables.min.js"></script>
  <script type="text/javascript" src="js/jquery.datatables/bootstrap-adapter/js/datatables.js"></script>
  <script type="text/javascript" src="js/jquery.niftymodals/js/jquery.modalEffects.js"></script>
  <script type="text/javascript" src="js/jquery.gritter/js/jquery.gritter.js"></script>

<script type="text/javascript">
  $(document).ready(function(){
	$('#manage-members').addClass('active');
    App.init();
    App.dataTables();
	  $('.md-trigger').modalEffects();
    $('.dataTables_filter input').addClass('form-control').attr('placeholder','Search');
    $('.dataTables_length select').addClass('form-control');

  <?php
      if($result == 1)
        echo '$.gritter.add({title: "Success", text: "VIP days have been added.",class_name: "success"});';
      if($result == 2)
        echo '$.gritter.add({title: "Success", text: "VIP days have been removed.",class_name: "success"});';
      if($result == 3)
        echo '$.gritter.add({title: "Success", text: "HWID successfully banned.",class_name: "success"});';
      if($result == 4)
        echo '$.gritter.add({title: "Success", text: "HWID successfully unbanned.",class_name: "success"});';
      if($result == 5)
        echo '$.gritter.add({title: "Success", text: "HWID successfully reset.",class_name: "success"});';
      if($result == 6)
        echo '$.gritter.add({title: "Success", text: "VIP days added for all users.",class_name: "success"});';
      if($result == 7)
        echo '$.gritter.add({title: "Success", text: "VIP days removed for all users.",class_name: "success"});';
       if($result == 8)
        echo '$.gritter.add({title: "Success", text: "VIP activated.",class_name: "success"});';
  ?>
  });

	$("button[name='edit']").click(function() {
		$("#editmember").focus();
		var currentRow=$(this).closest("tr");
		$("#nick").val(currentRow.find("td:eq(0)").text());
		$("#hwid").val(currentRow.find("td:eq(3)").text());
		$('html, body').animate({scrollTop: $("#editmember").offset().top}, 1500);
	});
</script>

<?php } ?>
