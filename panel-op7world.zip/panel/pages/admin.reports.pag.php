<?php
if(!defined('PROTECT'))exit;
if($group_session == GROUP_ADMIN){
?>

 <div class="row">
  <div class="col-md-12">
        <div class="block-flat">
            <div class="header">
                <h3>Latest VIP Days Activity</h3>
            <div class="content">
                <div class="table-responsive">
                    <table class="table table-bordered" id="datatable">
                        <thead>
                            <tr>
                                <th>Staff</th>
								<th>User</th>
                                <th>Date</th>
                                <th>Mesage</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
					        $p_sql = Connection::getInstance()->prepare("SELECT * FROM sys_reports WHERE report_mode ='VIP' AND report_date > DATE(NOW() - INTERVAL 30 DAY)");
						    $p_sql->execute();
                            $user_info = new User();
                          	while($row = $p_sql->fetch(PDO::FETCH_ASSOC))
                          	{
                        ?>
							    <tr>
								<td><?php echo $row['report_staff']; ?></td>
								<td><?php echo $row['report_user']; ?></td>
								<td><?php echo $row['report_date']; ?></td>
                                <td><?php echo $row['report_mesage']; ?></td>
								</tr>
                          <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
	</div>
  <div class="col-md-12">
        <div class="block-flat">
            <div class="header">
                <h3>Latest HWID Activity</h3>
            <div class="content">
                <div class="table-responsive">
                    <table class="table table-bordered" id="datatable">
                        <thead>
                            <tr>
                                <th>Staff</th>
								<th>User</th>
                                <th>Date</th>
                                <th>Mesage</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
					        $p_sql = Connection::getInstance()->prepare("SELECT * FROM sys_reports WHERE report_mode ='HWID' AND report_date > DATE(NOW() - INTERVAL 30 DAY)");
						    $p_sql->execute();
                            $user_info = new User();
                          	while($row = $p_sql->fetch(PDO::FETCH_ASSOC))
                          	{
                        ?>
							    <tr>
								<td><?php echo $row['report_staff']; ?></td>
								<td><?php echo $row['report_user']; ?></td>
								<td><?php echo $row['report_date']; ?></td>
                                <td><?php echo $row['report_mesage']; ?></td>
								</tr>
                          <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
	</div>
	</div>

  <?php require_once("./templates/script.php"); ?>
  <script type="text/javascript" src="js/jquery.datatables/jquery.datatables.min.js"></script>
  <script type="text/javascript" src="js/jquery.datatables/bootstrap-adapter/js/datatables.js"></script>
  <script type="text/javascript" src="js/jquery.niftymodals/js/jquery.modalEffects.js"></script>
  <script type="text/javascript" src="js/jquery.gritter/js/jquery.gritter.js"></script>

<script type="text/javascript">
  $(document).ready(function(){
	$('#reports').addClass('active');
    App.init();
    App.dataTables();
	$('.md-trigger').modalEffects();
    $('.dataTables_filter input').addClass('form-control').attr('placeholder','Search');
    $('.dataTables_length select').addClass('form-control');
  });
</script>

<?php } ?>
