<?php
if(!defined('PROTECT'))exit;
if($group_session == GROUP_ADMIN){

include "./library/classes/products.class.php";

$update_status = 0; // NULL

if(isset($_POST['game'])){
   if(addslashes($_POST['game']) != 'Select Game'){
      $Products = new Products(addslashes($_POST['game']));

      if(isset($_POST['version']) && $_POST['version'] != '')
		   $Products->changeProductVersion(addslashes($_POST['version']));

      if(isset($_POST['mode']) && $_POST['mode'] != 'Select Mode')
		   $Products->changeProductMode(addslashes($_POST['mode']));

      if(isset($_POST['download']) && $_POST['download'] != '')
       $Products->changeProductDownload(addslashes($_POST['download']));

	   $Products->changeProductStatus(isset($_POST['status']) ? 'ENABLED' : 'DISABLED');
      unset($Products);
      $update_status = 1;//UPDATE_OK
   }else
      $update_status = 2;//SELECT_GAME
}

$p_sql = Connection::getInstance()->prepare("SELECT * FROM sys_products");
$p_sql->execute();

?>
<div class="row">
   <div class="col-sm-6 col-md-6">
      <div class="block-flat">
         <div class="header">
            <h3>Loader Config</h3>
         </div>
         <div class="content">
            <form class="form-horizontal" action="index.php?page=manage_products" method="post" role="form">
			    <div class="form-group">
                <label class="col-sm-2 control-label">Game</label>
                <div class="col-sm-10">
                  <select name="game" class="form-control">
				          <option>Select Game</option>
                  <?php
                    while($row = $p_sql->fetch(PDO::FETCH_ASSOC))
                      echo "<option>{$row['product_name']}</option>";
                  ?>
                  </select>
                </div>
              </div>
              <div class="form-group">
              <label for="inputEmail3" class="col-sm-2 control-label">Version</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="version" placeholder="0.1">
              </div>
              </div>
			  	<div class="form-group">
                <label class="col-sm-2 control-label">Mode</label>
                <div class="col-sm-10">
                  <select name="mode" class="form-control">
				            <option>Select Mode</option>
                   <option>Free</option>
                   <option>Vip</option>
                  </select>
                </div>
              </div>
        <div class="form-group">
              <label for="inputEmail3" class="col-sm-2 control-label">Download</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" name="download" placeholder="https://">
              </div>
              </div>
			   <div class="form-group">
                <label class="col-sm-2 control-label">Enabled</label>
                <div class="col-sm-6">
                  <div class="switch" data-on="success">
                    <input name="status" type="checkbox">
                  </div>
                </div>
              </div>
              <div class="modal-footer">
              <div class="col-sm-offset-2 col-sm-11">
                <button type="submit" class="btn btn-primary">Save Config</button>
              </div>
              </div>
            </form>
          </div>
        </div>
      </div>
	  				<div class="col-sm-6 col-md-6">
					<div class="block-flat">
						<div class="header">
							<h3>Loader Information</h3>
						</div>
						<div class="content">
							<table>
								<thead>
									<tr>
										<th>Game</th>
										<th>Status</th>
										<th>Version</th>
										<th>Mode</th>
										<th>AC Status</th>
									</tr>
								</thead>
								<tbody>
                <?php
                $p_sql = Connection::getInstance()->prepare("SELECT * FROM sys_products");
                $p_sql->execute();
                  while($row_products = $p_sql->fetch(PDO::FETCH_ASSOC)){
                    $Products = new Products($row_products['product_name']);
                ?>
									<tr>
										<td><?php echo $row_products['product_name']; ?></td>
                <?php
                    if($Products->productStatus() == 'ENABLED')
                      echo '<td class="text-center"><span class="label label-success">Active</span>';
                    else
                      echo '<td class="text-center"><span class="label label-danger">Disabled</span>';
                ?>
										<td><?php echo $Products->productVersion();?></td>
										<td><?php echo $Products->productMode();?></td>
										<td>Undetect</td>
									</tr>
                <?php  unset($Products); }  ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
</div>

<?php require_once("./templates/script.php"); ?>
<script type="text/javascript" src="js/jquery.icheck/icheck.min.js"></script>

<script type="text/javascript">
   $(document).ready(function(){
	$('#manage-products').addClass('active');
   App.init();
   <?php
      if($update_status == 1)
      echo '$.gritter.add({title: "Success", text: "Loader information has been updated.",class_name: "success"});';
      if($update_status == 2)
         echo '$.gritter.add({title: "Error", text: "Select the game.",class_name: "danger"});';
   ?>
});
</script>
<?php } ?>