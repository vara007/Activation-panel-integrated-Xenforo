 <?php
 if(!defined('PROTECT'))exit;
 if($group_session == GROUP_ADMIN){

 	$admin_info = new User();
 ?>

			<div class="row">
			<div class="col-md-3">
					<div class="block-flat">
						<div class="content no-padding">
							<div class="overflow-hidden">
								<i class="fa fa-user fa-3x pull-left color-primary"></i>
								<h4 class="no-margin">Clients</h4>
								<p class="color-primary"></p>
							</div>
							<h1 class="no-margin big-text"><?php echo $admin_info->getUsers(); ?></h1>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="block-flat">
						<div class="content no-padding">
							<div class="overflow-hidden">
								<i class="fa fa-times fa-3x pull-left color-danger"></i>
								<h4 class="no-margin">Hwid Banished</h4>
								<p class="color-primary"></p>
							</div>
							<h1 class="no-margin big-text"><?php echo $admin_info->getHWIDs(); ?></h1>
						</div>
					</div>
				</div>
					<div class="col-md-3">
					<div class="block-flat">
						<div class="content no-padding">
							<div class="overflow-hidden">
								<i class="fa fa-shopping-cart fa-3x pull-left color-warning"></i>
								<h4 class="no-margin">Buys thi month</h4>
								<p class="color-primary"></p>
							</div>
							<h1 class="no-margin big-text"><?php echo $admin_info->getBuys(); ?></h1>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="block-flat">
						<div class="content no-padding">
							<div class="overflow-hidden">
								<i class="fa fa-gear  fa-3x pull-left color-success"></i> 
								<h4 class="no-margin">Reports this month</h4>
								<p class="color-primary"></p>
							</div>
							<h1 class="no-margin big-text"><?php echo $admin_info->getReports(); ?></h1>
						</div>
					</div>
				</div>
				<div class="col-sm-6 col-md-6">
					<div class="block-flat">
						<div class="header">
							<h3>Latest Purchases</h3>
						</div>
						<div class="content">
							<table class="no-border">
								<thead class="no-border">
									<tr>
										<th>User</th>
										<th>Seller</th>
										<th>Date</th>
										<th>Days</th>
									</tr>
								</thead>
								<tbody class="no-border-x no-border-y">
								<?php
					                $p_sql = Connection::getInstance()->prepare("SELECT * FROM sys_buys LIMIT 10");
						            $p_sql->execute();
                          			while($row = $p_sql->fetch(PDO::FETCH_ASSOC))
                          			{
								?>
									<tr>
										<td><?php echo $row['buy_buyer']; ?></td>
										<td><?php echo $row['buy_seller']; ?></td>
										<td><?php echo $row['buy_date']; ?></td>
										<td><?php echo $row['buy_days']; ?></td>
									</tr>
								<?php
									}
								?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
				<?php
					$p_sql = Connection::getInstance()->prepare("SELECT * FROM sys_products");
					$p_sql->execute();
				?>
				<div class="col-sm-6 col-md-6">
				<div class="block-flat">
						<div class="header">
						<h3>Products</h3>
						</div>
						<div class="content">
							<table>
								<thead>
									<tr>
										<th>Product</th>
										<th>Version</th>
										<th>Status</th>
										<th>Download</th>
									</tr>
								</thead>
								<tbody>
								<?php
									while($row = $p_sql->fetch(PDO::FETCH_ASSOC)){
								?>
								<tr>
									<td><?php echo $row['product_name']; ?></td>
									<td class="text-center">0.1</td>
									<td class="text-center"><span class="label label-success">Undetect</span></td>
									<td class="text-center">
									<?php if($group_session == GROUP_ADMIN || $group_session == GROUP_MOD || $group_session == GROUP_SELLER || $group_session == GROUP_VIP){
										if($row['product_status'] == 'ENABLED'){
									 ?>
									<button type='button' onclick="location.href='<?php echo $row['product_download']; ?>';" class="btn btn-success btn-xs"><i class="fa fa-cloud-download"></i> Download</button>
									<?php
										}
										else{
									?>
										<span class="badge badge-danger">Not available.</span>
									<?php
											}}
										}
									?>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
				<div class="col-sm-6 col-md-6">
				</div>
</div>

<?php require_once("./templates/script.php"); ?>
<script type="text/javascript">
    $(document).ready(function(){
    	$('#home').addClass('active');
		App.init();
	});
</script>
<?php } ?>