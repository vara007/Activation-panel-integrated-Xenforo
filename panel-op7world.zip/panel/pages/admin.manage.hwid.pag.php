 <?php
 if(!defined('PROTECT'))exit;
 if($group_session == GROUP_ADMIN ){
 ?>

    		<div class="row">
				<div class="block-flat">
						<div class="header">
						<h3>DWID Banned</h3>
						</div>
						<div class="content">
							<table>
						<thead>
							<tr>
                                <th>Name</th>
								<th>HWID</th>
                                <th>Date</th>
                                <th>Reason</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
					        $p_sql = Connection::getInstance()->prepare("SELECT * FROM sys_hwid");
						    $p_sql->execute();
                          	$user_info = new User();

                          while($row = $p_sql->fetch(PDO::FETCH_ASSOC))
                          {
                    	?>
							<tr>
							<td><?php echo $row['ban_user']; ?></td>
							<td><?php echo $row['ban_hwid']; ?></td>
							<td><?php echo $row['ban_date']; ?></td>
                            <td><?php echo $row['ban_reason']; ?></td>
							</tr>
                         <?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
<?php require_once("./templates/script.php"); ?>

<script type="text/javascript">
  $(document).ready(function(){
  $('#manage-computers').addClass('active');
  App.init();
  });
</script>

<?php } ?>