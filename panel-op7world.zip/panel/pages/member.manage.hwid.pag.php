<?php
  if(!defined('PROTECT'))exit;
  $p_sql = Connection::getInstance()->prepare("SELECT * FROM sys_users WHERE user_name = :Name");
  $p_sql->bindValue(":Name", $user_name);
  $p_sql->execute();
  $row = $p_sql->fetch(PDO::FETCH_ASSOC);

  $result = 0;

if(isset($_POST['reset']) && $_POST['reset'] == 'ok'){
  if(strtotime($row['user_expire_hwid']) < strtotime(date('Y-m-d H:i:s'))){
    $user_action   = new User($user_name);
    $user_action->resetHWID();
    $result = 1;
    unset($user_action);
  }
}
?>

<div class="row">
  <div class="col-sm-5 col-md-5">
    <div class="block-flat">
      <div class="header">
            <h3>Reset HWID</h3>
          </div>
          <div class="content">
            <form class="form-horizontal" action="index.php?page=member_manage_hwid" method="post" role="form">
          <div class="content">
            <h5 class="title text-center"><strong>Reset your HWID?</strong></h5>
            <p class="text-center">Your reset will only be available in: <span class="badge badge-success"><?php echo $row['user_expire_hwid']; ?></span></p>
              <hr/>
              <div class="form-group">
              <input type="hidden" id="reset" name="reset" value="ok">
              </div>
             <p class="spacer text-center">Do you have a problem?<a href="#"> Contact Support</a>.</p>
             <button
              <?php
              if(($row['user_status'] == 'BANNED') || strtotime($row['user_expire_hwid']) > strtotime(date('Y-m-d H:i:s')))
                echo 'disabled="disabled"';
              ?>
              class="btn btn-block btn-success btn-rad btn-lg" type="submit"><i class="fa fa-refresh"></i> Reset HWID</button>
          </div>
            </form>
          </div>
        </div>
      </div>
	  				<div class="col-sm-7 col-md-7">
					<div class="block-flat">
						<div class="header">
							<h3>HWID Information</h3>
						</div>
						<div class="content">
							<table>
								<thead>
									<tr>
										<th>HWID</th>
										<th>Last Reset</th>
										<th>Nex Reset</th>
										<th>Status</th>
									</tr>
							  </thead>
							<tbody>
						<tr>
							<td><?php echo $row['user_hwid']; ?></td>
							<td><?php echo $row['user_reseted_hwid']; ?></td>
							<td><?php echo $row['user_expire_hwid']; ?></td>
						<?php
              if($row['user_status'] == 'ACTIVE')
                echo '<td class="text-center"><span class="label label-success">Active</span>';
              else
                echo '<td class="text-center"><span class="label label-danger">Banned</span>';
            ?>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
    <?php if($row['user_status'] == 'BANNED'){ ?>
    <div class="alert alert-danger">
  <strong>Danger!</strong> Your hwid is banned, you can not reset.
</div>
  <?php } ?>
	</div>
</div>

<?php require_once("./templates/script.php"); ?>
<script type="text/javascript" src="js/jquery.icheck/icheck.min.js"></script>

<script type="text/javascript">
  $(document).ready(function(){
		$('#member-manage-hwid').addClass('active');
    App.init();

    <?php
      if($result == 1)
        echo '$.gritter.add({title: "Success", text: "HWID successfully reset.",class_name: "success"});';
    ?>
  });
</script>