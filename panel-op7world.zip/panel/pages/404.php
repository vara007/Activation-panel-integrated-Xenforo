	<div class="page-error">
		<h1 class="color-primary number text-center">404</h1>
		<h2 class="color-primary description text-center">Sorry, but this page doesn't exists!</h2>
		<h3 class="text-center">Would you like to go <a href="index.php?page=home">home</a>?</h3>
	</div>
	<div class="text-center copy">&copy; 2017 <a href="#">LACheats</a></div
<?php require_once("./templates/script.php"); ?>

  <script type="text/javascript">
      $(document).ready(function(){
        App.init();
      });
</script>

