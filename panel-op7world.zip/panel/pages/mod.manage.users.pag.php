<?php
if(!defined('PROTECT'))exit;
if($group_session == GROUP_ADMIN || $group_session == GROUP_SELLER || $group_session == GROUP_MOD){
$result = 0;
if(isset($_POST['user']) && isset($_POST['action']) && !empty($_POST['user']) && !empty($_POST['action'])){

	$post_name 		= 			addslashes($_POST['user']);
	$post_action 	= 			addslashes($_POST['action']);

	$user_action = new User($post_name);
  	if($post_action == 'reset'){
   		$user_action->resetHWID();
      $user_action->addReport($user_name, $post_name, 'HWID', "HWID reseted.");
    	$result = 1;
  	}
  	unset($user_action);
}

?>

    <div class="row">
        <div class="col-sm-6 col-md-6">
        <div class="block-flat">
          <div class="header">
            <h3>Edit Member</h3>
          </div>
          <div class="content">
            <form id="edit-member" class="form-horizontal" role="form" action="index.php?page=mod_manage_members" method="post">
              <div class="form-group">
              <label for="nick" class="col-sm-2 control-label">Nick</label>
              <div id="editmember" class="col-sm-8">
                <input type="hidden" id="action" name="action" value="reset">
                <input name="user" type="text" class="form-control" id="nick" placeholder="">
              </div>
              </div>
          <div class="content">
              <hr/>
              <div class="form-group">
              </div>
             <button class="btn btn-block btn-success btn-rad btn-lg" type="submit"><i class="fa fa-refresh"></i> Reset HWID</button>
          </div>
            </form>
          </div>
        </div>
      </div>
	</div>

  <?php require_once("./templates/script.php"); ?>
  <script type="text/javascript" src="js/jquery.datatables/jquery.datatables.min.js"></script>
  <script type="text/javascript" src="js/jquery.datatables/bootstrap-adapter/js/datatables.js"></script>
  <script type="text/javascript" src="js/jquery.niftymodals/js/jquery.modalEffects.js"></script>
  <script type="text/javascript" src="js/jquery.gritter/js/jquery.gritter.js"></script>

<script type="text/javascript">
  $(document).ready(function(){
	$('#mod-manage-members').addClass('active');
    App.init();

  <?php
      if($result == 1)
        echo '$.gritter.add({title: "Success", text: "HWID successfully reset.",class_name: "success"});';
      ?>
  });
</script>
<?php } ?>
