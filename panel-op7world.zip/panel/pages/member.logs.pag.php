<?php
if(!defined( 'PROTECT'))exit;
?>

<div class="row">
  <div class="col-md-12">
        <div class="block-flat">
            <div class="header">
                <h3>Last connections for 5 days</h3>
            <div class="content">
                <div class="table-responsive">
                    <table class="table table-bordered" id="datatable">
                        <thead>
                            <tr>
                                <th>Date</th>
								                <th>Ip</th>
                                <th>Browser</th>
                                <th>Status</th>
								                <th>Mode</th>
                            </tr>
                        </thead>
                        <tbody>
                      <?php
                          $p_sql = Connection::getInstance()->prepare("SELECT * FROM sys_connections  WHERE con_user =:Name AND con_date > DATE(NOW() - INTERVAL 5 DAY)");
                          $p_sql->bindValue(":Name", $user_name);
						              $p_sql->execute();
                          while($row = $p_sql->fetch(PDO::FETCH_ASSOC)){
								            if($row['con_status'] == 'LOGIN_OK'){
                      ?>
								        <tr class='success'>
								              <td><?php echo $row['con_date']; ?></td>
								              <td><?php echo $row['con_ip']; ?></td>
								              <td><?php echo $row['con_browser']; ?></td>
								              <td><?php echo $row['con_status']; ?></td>
								              <td><?php echo $row['con_mode']; ?></td>
                              </tr>
                      <?php }
                            else{
                      ?>
                            <tr class='danger'>
                              <td><?php echo $row['con_date']; ?></td>
                              <td><?php echo $row['con_ip']; ?></td>
                              <td><?php echo $row['con_browser']; ?></td>
                              <td><?php echo $row['con_status']; ?></td>
                              <td><?php echo $row['con_mode']; ?></td>
                              </tr>
                      <?php
                            }
                          }
                      ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
	</div>
	</div>

<?php require_once("./templates/script.php"); ?>
<script type="text/javascript" src="js/jquery.datatables/jquery.datatables.min.js"></script>
<script type="text/javascript" src="js/jquery.datatables/bootstrap-adapter/js/datatables.js"></script>
<script type="text/javascript" src="js/jquery.niftymodals/js/jquery.modalEffects.js"></script>
<script type="text/javascript" src="js/jquery.gritter/js/jquery.gritter.js"></script>

<script type="text/javascript">
  $(document).ready(function(){
	  $('#access-log').addClass('active');
    App.init();
    App.dataTables();
		$('.md-trigger').modalEffects();
    $('.dataTables_filter input').addClass('form-control').attr('placeholder','Search');
    $('.dataTables_length select').addClass('form-control');
  });
</script>
