    
    <div class="row">
    </div>

<?php require_once("./templates/script.php"); ?>

<script type="text/javascript">
  $(document).ready(function(){
  $('#buy-products').addClass('active');
  App.init();
  });
</script>