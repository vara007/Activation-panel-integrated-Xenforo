<?php

include "library/config.php";
include "library/classes/tools.class.php";
include "library/classes/connection.class.php";
include "library/classes/xenforo.class.php";
include "library/classes/user.class.php";
include "library/classes/products.class.php";

function xor_this($string) {
    $key = ('ffff');
    $text = $string;
    $outText = '';
    for($i=0; $i<strlen($text); )
    {
        for($j=0; ($j<strlen($key) && $i<strlen($text)); $j++,$i++)
        {
            $outText .= $text{$i} ^ $key{$j};
        }
    }
    return $outText;
}

if(!isset($_POST['user']) || !isset($_POST['pass']) || !isset($_POST['hwid']) || !isset($_POST['version']) || !isset($_POST['product']))
	die("LOGIN_ERROR_0");
if(empty($_POST['user']) || empty($_POST['pass']) || empty($_POST['hwid']) || empty($_POST['version']) || empty($_POST['product']))
	die("LOGIN_ERROR_1");

$user_name 			= 	addslashes($_POST['user']);
$user_pass 			= 	addslashes($_POST['pass']);
$user_hwid 			= 	addslashes($_POST['hwid']);
$p_product_version 		= 	addslashes($_POST['version']);
$p_product_name 		= 	addslashes($_POST['product']);

$Xenforo = new Xenforo();

if($Xenforo->xf_login($user_name, $user_pass)){
	date_default_timezone_set('America/Sao_Paulo');
	$Products = new Products($p_product_name);
	if($Products->productStatus() != 'ENABLED')
		die (md5("PRODUCT_DISABLED"));//Estamos en mantenimiento, por favor espere.
	if($Products->productVersion() != $p_product_version)
		die (md5("PRODUCT_OUTDATED"));//Esta versión esta desactualizada, descargue la versión más reciente.

	//if($Xenforo->getUserGroupID($usuario) == GROUP_ADMIN)
	//	die ('LOGIN_OK".date('Y-m-d H:i')));

	$User = new User($user_name);
	if(!$User->userExisting()){
			$User->registerUser($user_name, '0000-00-00 00:00:00');
			unset($User);
			$User = new User($user_name);
		}

	if($User->getUserHWID() != $user_hwid  && $User->getUserHWID() != null)
		die (md5("TOKEN_ERROR"));//El HWID de esta cuenta pertenece a otra pc, si continua intentando acceder a esta cuenta con HWID diferente, será baneada automáticamente.

	if($User->getUserHWID() == null)
		$User->registerHWID($user_hwid); //Su HWID se registró en este pc.

	if($User->isHWIDBanned($user_name, $user_hwid))
		die (md5("TOKEN_BANNED"));//Su HWID fue baneado por infringir nuestras reglas.
	if($Products->productMode() == 'FREE')
		die (md5("LOGIN_OK"));//Su HWID fue baneado por infringir nuestras reglas.

		if($User->getUserDaysVIP() <= 0){
			if($Xenforo->userGroupID($user_name) == GROUP_VIP)
				$Xenforo->setUserGroup($user_name, GROUP_EXVIP);
			die (md5("VIP_EXPIRED"));//Sus días de VIP expiraron.
		}
		else
			die (md5("LOGIN_OK"));//Se logueo correctamente, inicie el juego.
	}
	else
		die (md5("LOGIN_ERROR_2"));//Usuario o contraseña incorrecta.

?>

