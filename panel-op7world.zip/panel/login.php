<?php
error_reporting(2047);
ini_set("display_errors",1);
if(isset($_GET['logout'])){
    session_start();
    session_destroy();
}

include("library/config.php");
$login_status = 0; // NULL
if (isset($_POST['user']) and isset($_POST['pass'])){
	include("library/classes/tools.class.php");
    include("library/classes/xenforo.class.php");
    include "library/classes/connection.class.php";
	include("library/classes/user.class.php");

	$user  = addslashes($_POST['user']);
	$pass  = addslashes($_POST['pass']);

	$Tools 	= new Tools();
	$Xenforo = new Xenforo();
	$User = new User($user);

	if ($Xenforo->xf_login($user, $pass)){
			$login_status = 1; //LOGIN_OK
			if (!isset($_SESSION)) session_start();
			session_regenerate_id();
			$_SESSION['user']  = $user;
			$_SESSION['pass']  = $pass;
			if(!$User->userExisting())
				$User->registerUser($user, '0000-00-00 00:00:00');
			$User->addLogConnection($user, 'Web', 'LOGIN_OK', $Tools->get_browser_name(), $Tools->getIP());
			header('location: index.php?page=home');
	 }else{
	 	$login_status = 2; // LOGIN_ERROR
	 }

  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="shortcut icon" href="images/favicon.png">

	<title><?php echo SITE_NAME; ?> | Login</title>
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,400italic,700,800' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Raleway:300,200,100' rel='stylesheet' type='text/css'>

	<!-- Bootstrap core CSS -->
	<link href="js/bootstrap/dist/css/bootstrap.css" rel="stylesheet">

	<link rel="stylesheet" href="fonts/font-awesome-4/css/font-awesome.min.css">
	<!-- Custom styles for this template -->
	<link href="css/style.css" rel="stylesheet"/>

</head>

<body class="texture">

<div id="cl-wrapper" class="login-container">

	<div class="middle-login">
		<div class="block-flat">
			<div class="header">
				<h3 class="text-center"><img class="logo-img" src="https://image.ibb.co/eobbiQ/Logo_Op7_Worl_D.png" alt="logo"/></h3>
			</div>
			<div>
				<form style="margin-bottom: 0px !important;" method="post"class="form-horizontal" action="login.php">
					<div class="content">
						<h4 class="title">Login Access</h4>
							<div class="form-group">
								<div class="col-sm-12">
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-user"></i></span>
										<input type="text" name="user" placeholder="Username" id="user" class="form-control">
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-12">
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-lock"></i></span>
										<input type="password" name="pass" placeholder="Password" id="pass" class="form-control">
									</div>
								</div>
							</div>
							<?php if($login_status == 2){ ?>
							<div class="form-group">
							<div class="col-sm-12">
								<div class="alert alert-danger">
								<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
								<i class="fa fa-times-circle sign"></i><strong>Error!</strong>User or password incorrect!
							 </div>
							  </div>
							 </div>
							 <?php } ?>
					</div>
					<div class="foot">
						<button class="btn btn-primary" data-dismiss="modal" type="submit">Login</button>
					</div>
				</form>
			</div>
		</div>
		<div class="text-center out-links"><a href="#">&copy; 2018 <?php echo SITE_NAME; ?></a></div>
	</div>

</div>

<script src="js/jquery.js"></script>
	<script type="text/javascript" src="js/behaviour/general.js"></script>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
 <script src="js/behaviour/voice-commands.js"></script>
 <script src="js/bootstrap/dist/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.flot/jquery.flot.js"></script>
<script type="text/javascript" src="js/jquery.flot/jquery.flot.pie.js"></script>
<script type="text/javascript" src="js/jquery.flot/jquery.flot.resize.js"></script>
<script type="text/javascript" src="js/jquery.flot/jquery.flot.labels.js"></script>
</body>
</html>
