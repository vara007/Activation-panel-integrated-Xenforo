<?php
	define('PROTECT',1);
	switch ($Tools->getPage()){
		case "home":{
			if($group_session == GROUP_ADMIN)
				include"pages/admin.pag.php";
			else
				include"pages/member.pag.php";
		}
		break;
		case "manage_members":
		    include"pages/admin.manage.users.pag.php";
		break;
		case "manage_hwids":
		    include"pages/admin.manage.hwid.pag.php";
		break;
		case "manage_products":
		    include"pages/admin.manage.products.pag.php";
		break;
		case "reports":
		    include"pages/admin.reports.pag.php";
		break;
		case "buy_products":
		    include"pages/member.buy.pag.php";
		break;
		case "member_manage_hwid":
		    include"pages/member.manage.hwid.pag.php";
		break;
		case "access_log":
		    include"pages/member.logs.pag.php";
		break;
		case "mod_manage_members":
		    include"pages/mod.manage.users.pag.php";
		break;
		default:{
			if($group_session == GROUP_ADMIN)
				include"pages/admin.pag.php";
			else
				include"pages/member.pag.php";
		}
		break;
	}
    require_once("templates/footer.php");

    //key = matreb
?>

