<?php

class Products {

	private $product_info;
	function __construct($product_name){
		$p_sql = Connection::getInstance()->prepare("SELECT * FROM sys_products WHERE product_name = :Name");
        $p_sql->bindValue(":Name", $product_name);
        $p_sql->execute();
        $this->product_info = $p_sql->fetch(PDO::FETCH_ASSOC);
	}

	public function productVersion(){
		return $this->product_info['product_version'];
	}

	public function productStatus(){
		return $this->product_info['product_status'];
	}

	public function productMode(){
		return $this->product_info['product_mode'];
	}

	public function changeProductMode($product_mode){
        $p_sql = Connection::getInstance()->prepare("UPDATE sys_products SET product_mode = :Mode WHERE product_name = :Name");
        $p_sql->bindValue(":Name", $this->product_info['product_name']);
		$p_sql->bindValue(":Mode", $product_mode);
        $p_sql->execute();
	}
	public function changeProductDownload($product_url){
        $p_sql = Connection::getInstance()->prepare("UPDATE sys_products SET product_download = :Url WHERE product_name = :Name");
        $p_sql->bindValue(":Name", $this->product_info['product_name']);
		$p_sql->bindValue(":Url", $product_url);
        $p_sql->execute();
	}

	public function changeProductStatus($product_status){
		$p_sql = Connection::getInstance()->prepare("UPDATE sys_products SET product_status = :Status WHERE product_name = :Name");
        $p_sql->bindValue(":Name", $this->product_info['product_name']);
		$p_sql->bindValue(":Status", $product_status);
        $p_sql->execute();
	}

	public function changeProductVersion($product_version){
		$p_sql = Connection::getInstance()->prepare("UPDATE sys_products SET product_version = :Version WHERE product_name = :Name");
        $p_sql->bindValue(":Name", $this->product_info['product_name']);
		$p_sql->bindValue(":Version", $product_version);
        $p_sql->execute();
	}
}
?>