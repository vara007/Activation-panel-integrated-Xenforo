<?php
class Tools
{
    private function fixString($value, $string)
    {
        $result = str_replace($string, "", $value);
        return $result;
    }
	public function getPage()
	{
		if(!empty($_GET['page']))
			return $_GET['page'];
		else
			return 'home';
	}
	public function makeGet($param)
	{
		return addslashes(@$_GET[$param]);
	}
    private function setupCipher()
    {
        $iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
        return array(pack('H*', "bcb04b7e103a0cd8b54763051cef08bc55abe029fdebae5e1d417e2ffb2a00a3"),
            $iv_size,
            mcrypt_create_iv($iv_size, MCRYPT_DEV_URANDOM)
        );
    }
    public function Encrypt($string)
    {
        list($key, $iv_size, $iv) = $this->setupCipher();
        $string = $iv . mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $key, $string, MCRYPT_MODE_CBC, $iv);
        return trim(base64_encode($string), "\0");
    }

    public function Decrypt($string)
    {
        list($key, $iv_size) = $this->setupCipher();
        $string = base64_decode($string);
        $iv_dec = substr($string, 0, $iv_size);
        $ciphertext_dec = substr($string, $iv_size);
        return trim(mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $key, $ciphertext_dec, MCRYPT_MODE_CBC, $iv_dec), "\0");
    }

    public function getIP()
    {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } else if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return $ip;
    }

    public function get_browser_name()
    {
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        if (strpos($user_agent, 'Opera') || strpos($user_agent, 'OPR/')) return 'Opera';
        elseif (strpos($user_agent, 'Edge')) return 'Edge';
        elseif (strpos($user_agent, 'Chrome')) return 'Chrome';
        elseif (strpos($user_agent, 'Safari')) return 'Safari';
        elseif (strpos($user_agent, 'Firefox')) return 'Firefox';
        elseif (strpos($user_agent, 'MSIE') || strpos($user_agent, 'Trident/7')) return 'Internet Explorer';
        return 'Other';
    }
}
?>