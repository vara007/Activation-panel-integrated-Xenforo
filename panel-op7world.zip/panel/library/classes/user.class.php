<?php

class User{
	private $user_info;
	function __construct($user_name = null){
		if($user_name != null){
			$p_sql = Connection::getInstance()->prepare("SELECT * FROM sys_users WHERE user_name = :Name");
			$p_sql->bindValue(":Name", $user_name);
			$p_sql->execute();
			$this->user_info = $p_sql->fetch(PDO::FETCH_ASSOC);
		}
	}

	public function getBuys()
    {
        $p_sql = Connection::getInstance()->prepare("SELECT COUNT(*) FROM sys_buys WHERE MONTH(buy_date) = MONTH(CURRENT_DATE())");
        $p_sql->execute();
        return $p_sql->fetchColumn();
    }

    public function getReports()
    {
        $p_sql = Connection::getInstance()->prepare("SELECT COUNT(*) FROM sys_reports WHERE MONTH(report_date) = MONTH(CURRENT_DATE())");
        $p_sql->execute();
        return $p_sql->fetchColumn();
    }

    public function getHWIDs()
    {
        $p_sql = Connection::getInstance()->prepare("SELECT COUNT(*) FROM sys_hwid");
        $p_sql->execute();
        return $p_sql->fetchColumn();
    }

    public function getUsers()
    {
        $p_sql = Connection::getInstance()->prepare("SELECT COUNT(*) FROM sys_users WHERE user_expire > NOW()");
        $p_sql->execute();
        return $p_sql->fetchColumn();
    }

	public function getUserDaysVIP($user_name = null){
		if($user_name == null)
			return $this->getDays($this->user_info['user_expire']);
		else
			return $this->getDays($user_name);
	}

	public function getUserHWID(){
		return $this->user_info['user_hwid'];
	}

	public function getUserExpireHWID(){
		return $this->user_info['user_expire_hwid'];
	}

	public function getUserBuys($user_name = null)
	{
		if($user_name == null){
       		$p_sql = Connection::getInstance()->prepare("SELECT COUNT(*) FROM sys_buys WHERE buy_buyer = :Name");
        	$p_sql->bindValue(":Name", $this->user_info['user_name']);
        	$p_sql->execute();
        	return $p_sql->fetchColumn();
   		}
    	else{
			$p_sql = Connection::getInstance()->prepare("SELECT COUNT(*) FROM sys_buys WHERE buy_buyer = :Name");
        	$p_sql->bindValue(":Name", $user_name);
        	$p_sql->execute();
        	return $p_sql->fetchColumn();
    	}
	}

	public function getUserResets($user_name = null)
	{
		if($user_name == null){
       		$p_sql = Connection::getInstance()->prepare("SELECT COUNT(*) FROM sys_resets WHERE reset_name = :Name");
        	$p_sql->bindValue(":Name", $this->user_info['user_name']);
        	$p_sql->execute();
        	return $p_sql->fetchColumn();
   		}
    	else{
			$p_sql = Connection::getInstance()->prepare("SELECT COUNT(*) FROM sys_resets WHERE reset_name = :Name");
        	$p_sql->bindValue(":Name", $user_name);
        	$p_sql->execute();
        	return $p_sql->fetchColumn();
    	}
	}

	public function getUserConnections($user_name = null)
	{
		if($user_name == null){
       		$p_sql = Connection::getInstance()->prepare("SELECT COUNT(*) FROM sys_connections WHERE con_user = :Name");
        	$p_sql->bindValue(":Name", $this->user_info['user_name']);
        	$p_sql->execute();
        	return $p_sql->fetchColumn();
   		}
    	else{
			$p_sql = Connection::getInstance()->prepare("SELECT COUNT(*) FROM sys_connections WHERE con_user = :Name");
        	$p_sql->bindValue(":Name", $user_name);
        	$p_sql->execute();
        	return $p_sql->fetchColumn();
    	}
	}

	public function getDays($day_end)
    {
        date_default_timezone_set('America/Sao_Paulo');
        $date_start          = strtotime(date('Y-m-d'));
        $date_end            = strtotime($day_end);
        $diference           = $date_end - $date_start;
        $days                = (int)($diference / (60 * 60 * 24));
        if($days > 0)
            return $days;
        else
            return 0;
    }

	public function addDaysVIP($days, $user_name){
		date_default_timezone_set('America/Sao_Paulo');
		if($this->userExisting()){
			if($this->getDays($this->user_info['user_expire']) <= 0 ){
				$new_data = date('Y-m-d H:i:s',strtotime("+".$days." days"));
			}
			else
			{
				$days = $this->getDays($this->user_info['user_expire']) + $days;
				$new_data = date('Y-m-d H:i:s',strtotime("+".$days." days"));
			}

			$p_sql = Connection::getInstance()->prepare("UPDATE sys_users SET user_expire = :Expire WHERE user_name = :Name");
			$p_sql->bindValue(":Name", $user_name);
			$p_sql->bindValue(":Expire", $new_data);
			$p_sql->execute();
		}
		else{
			$new_data = date('Y-m-d H:i:s',strtotime("+".$days." days"));
			$this->registerUser($user_name, $new_data);
		}
	}

	public function addDaysVIPALL($days){
		date_default_timezone_set('America/Sao_Paulo');
		$p_sql = Connection::getInstance()->prepare("UPDATE sys_users SET user_expire = ADDDATE( user_expire, INTERVAL {$days} DAY) WHERE user_expire > NOW()");
		$p_sql->execute();
	}

	public function subDaysVIPALL($days){
		date_default_timezone_set('America/Sao_Paulo');
		$p_sql = Connection::getInstance()->prepare("UPDATE sys_users SET user_expire = ADDDATE( user_expire, INTERVAL -{$days} DAY) WHERE user_expire > NOW()");
		$p_sql->execute();
	}

	public function subDaysVIP($days){
		date_default_timezone_set('America/Sao_Paulo');
		if($this->getDays($this->user_info['user_expire']) <= 0 )
			$new_data = date('Y-m-d H:i:s',strtotime("+".$days." days"));
		else
		{
			$days = $this->getDays($this->user_info['user_expire']) - $days;
			$new_data = date('Y-m-d H:i:s',strtotime("+".$days." days"));
		}
		$p_sql = Connection::getInstance()->prepare("UPDATE sys_users SET user_expire = :Expire WHERE user_name = :Name");
		$p_sql->bindValue(":Name", $this->user_info['user_name']);
		$p_sql->bindValue(":Expire", $new_data);
		$p_sql->execute();
	}
	public function activeVIP($days, $seller){
		date_default_timezone_set('America/Sao_Paulo');
		$tools = new Tools();
		$p_sql = Connection::getInstance()->prepare("INSERT INTO sys_buys (buy_buyer, buy_date, buy_seller, buy_days) VALUES (:User, NOW(), :Seller, :Days)");
        $p_sql->bindValue(":User", 		$this->user_info['user_name']);
        $p_sql->bindValue(":Seller", 	$seller);
        $p_sql->bindValue(":Days", 		$days);
        $p_sql->execute();
	}

	public function resetHWID(){
		if(!$this->isHWIDBanned($this->user_info['user_name'], $this->user_info['user_hwid'])){
			date_default_timezone_set('America/Sao_Paulo');
        	$p_sql = Connection::getInstance()->prepare("UPDATE sys_users SET user_hwid = '', user_reseted_hwid = NOW(), user_expire_hwid = NOW() + INTERVAL 7 DAY WHERE user_name = :Name");
        	$p_sql->bindValue(":Name", $this->user_info['user_name']);
        	$p_sql->execute();
    	}
    }

	public function registerHWID($user_hwid){
        $p_sql = Connection::getInstance()->prepare("UPDATE sys_users SET user_hwid = :Hwid WHERE user_name = :Name");
        $p_sql->bindValue(":Name", $this->user_info['user_name']);
		$p_sql->bindValue(":Hwid", $user_hwid);
        $p_sql->execute();
    }

    public function banHWID(){
    	if($this->user_info['user_hwid'] != ''){
			$p_sql = Connection::getInstance()->prepare("INSERT INTO sys_hwid (ban_user, ban_hwid, ban_date, ban_reason) VALUES (:Name, :Hwid, NOW(), :Reason)");
        	$p_sql->bindValue(":Name", 		$this->user_info['user_name']);
        	$p_sql->bindValue(":Hwid", 		$this->user_info['user_hwid']);
        	$p_sql->bindValue(":Reason", 	'Fraud');
        	$p_sql->execute();

        	$p_sql = Connection::getInstance()->prepare("UPDATE sys_users SET user_status = 'BANNED' WHERE user_name = :Name");
        	$p_sql->bindValue(":Name", $this->user_info['user_name']);
        	$p_sql->execute();
    	}
    }

	public function unbanHWID(){
        $p_sql = Connection::getInstance()->prepare("DELETE FROM sys_hwid WHERE ban_user = :Name");
        $p_sql->bindValue(":Name", $this->user_info['user_name']);
        $p_sql->execute();

        $p_sql = Connection::getInstance()->prepare("UPDATE sys_users SET user_status = 'ACTIVE' WHERE user_name = :Name");
       	$p_sql->bindValue(":Name", $this->user_info['user_name']);
        $p_sql->execute();
    }

	public function isHWIDBanned($user, $token){
		$p_sql = Connection::getInstance()->prepare("SELECT * FROM sys_hwid WHERE ban_user = :User OR ban_hwid = :Token");
        $p_sql->bindValue(":User",  $user);
        $p_sql->bindValue(":Token", $token);
        $p_sql->execute();
		if($p_sql->fetch(PDO::FETCH_ASSOC))
			return true;
		else
			return false;
	}

	public function userExisting(){
		if($this->user_info)
			return true;
		else
			return false;
	}

	public function registerUser($user_name, $user_expire){
		date_default_timezone_set('America/Sao_Paulo');
		$tools = new Tools();
		$p_sql = Connection::getInstance()->prepare("INSERT INTO sys_users (user_name, user_expire, user_reseted_hwid, user_expire_hwid, user_status, user_lastip) VALUES (:Name, :Expire, NOW(), NOW(), :Status, :IP)");
        $p_sql->bindValue(":Name", 		$user_name);
        $p_sql->bindValue(":Expire", 	$user_expire);
        $p_sql->bindValue(":Status", 	'ACTIVE');
		$p_sql->bindValue(":IP", 		$tools->getIP());
        $p_sql->execute();
	}

	public function addLogConnection($user, $mode, $status, $browser, $ip){
		date_default_timezone_set('America/Sao_Paulo');
		$p_sql = Connection::getInstance()->prepare("INSERT INTO sys_connections (con_user, con_ip, con_date, con_mode, con_browser, con_status) VALUES (:Name, :Ip, NOW(), :Mode, :Browser, :Status)");
        $p_sql->bindValue(":Name", 		$user);
        $p_sql->bindValue(":Ip", 		$ip);
        $p_sql->bindValue(":Mode", 		$mode);
        $p_sql->bindValue(":Browser", 	$browser);
		$p_sql->bindValue(":Status", 	$status);
        $p_sql->execute();
	}
	public function addReport($staff, $user, $mode, $mesage){
		date_default_timezone_set('America/Sao_Paulo');
		$p_sql = Connection::getInstance()->prepare("INSERT INTO sys_reports (report_staff, report_user, report_date, report_mode, report_mesage) VALUES (:Staff, :User, NOW(), :Mode, :Mesage)");
        $p_sql->bindValue(":Staff", 	$staff);
        $p_sql->bindValue(":User", 		$user);
        $p_sql->bindValue(":Mode", 		$mode);
        $p_sql->bindValue(":Mesage", 	$mesage);
        $p_sql->execute();
	}
}
?>
