<?php
class Xenforo
{
	//define('XF_ROOT', '../forum');
	function __construct(){
		require_once('../library/XenForo/Autoloader.php');
		//require_once( XF_ROOT . '/library/Dark/TaigaChat/Model/TaigaChat.php');
		XenForo_Autoloader::getInstance()->setupAutoloader('../library');
		XenForo_Application::initialize('../library', '../');
		XenForo_Application::set('page_start_time', TIMENOW);
	}

	public function sessionUsername(){
		$dependencies = new XenForo_Dependencies_Public();
		$dependencies->preLoadData();
		XenForo_Session::startPublicSession();
		$visitor = XenForo_Visitor::getInstance();
		return ($visitor->username);
	}

	function setUserGroup($name, $group){
    	$userModel = XenForo_Model::create('XenForo_Model_User');
    	$user = $userModel->getUserByName($name);
    	$userId = $user['user_id'];
    	$writer = XenForo_DataWriter::create('XenForo_DataWriter_User');
    	if ($userId) {
        	$writer->setExistingData($userId);
    	}
    		$writer->set('user_group_id', $group);
    		$writer->save();
    }

	public function xf_userinfo(){
		$userModel = XenForo_Model::create('XenForo_Model_User');
		$criteria = array(
        'user_group_id' => array (1,2,3,4,5)
		);
		$options = array(
        'join' => XenForo_Model_User::FETCH_USER_FULL,
        'order' => 'user_id'
		);
    return  $userModel->getModelFromCache('XenForo_Model_User')->getUsers($criteria, $options);
	}

	function xenforoBot($message){
        $visitor = XenForo_Visitor::getInstance();
        $bot_id = intval(XenForo_Application::get('options')->dark_taigachat_botid);
        $dws = XenForo_DataWriter::create('Dark_TaigaChat_DataWriter_Message');
        $dw = XenForo_DataWriter::create('Dark_TaigaChat_DataWriter_Message');
        $dws->setOption(Dark_TaigaChat_DataWriter_Message::OPTION_IS_AUTOMATED, true);
        $dws->set('user_id', $bot_id);
        $dws->set('username', 'Scott');
        $dws->set('message', $message);
        $dws->save();
	}

    public function xf_login($user, $pass){

        $db = XenForo_Application::getDb();
        $data = $db->fetchOne('SELECT auth.data FROM xf_user_authenticate AS auth INNER 
		JOIN xf_user AS user ON (user.user_id = auth.user_id) WHERE user.username = ?', $user);
        $auth = XenForo_Authentication_Abstract::createDefault();
        $auth->setData($data);
        $check = $auth->authenticate($user, $pass);
        return $check;
    }

	public function userGroupID($usuario){

        $userModel = XenForo_Model::create('XenForo_Model_User');
        $user = $userModel->getUserByName($usuario);
        return $user['user_group_id'];
    }

	public function getUser_Info($username,$param)
	{
		$userModel = XenForo_Model::create('XenForo_Model_User');
        $user = $userModel->getUserByName($username);
        return $user[$param];
	}

	public function getUser_Avatar($username, $size){
		$userModel = XenForo_Model::create('XenForo_Model_User');
        $user = $userModel->getUserByName($username);
		$group = floor($user['user_id'] / 1000);
		if($user['avatar_date'] == 0)
			return FORUM_ROOT . "styles/default/xenforo/avatars/avatar_s.png";
		else
			return FORUM_ROOT . XenForo_Application::$externalDataUrl . "/avatars/".$size."/".$group."/".$user['user_id'].".jpg?.".$user['avatar_date'];
	}
}

?>