<?php
	define("ENCRYPTION_KEY", "08er4wew214e");

	define('SITE_NAME', 'Op7World');
	define('DB_HOST', 'localhost');
	define('DB_NAME', 'rwihvsfo_sys_panel');
	define('DB_USER', 'rwihvsfo_op7world');
	define('DB_PASS', 'a]A-kT2leTk=');

	define('GROUP_ADMIN', 		3);
	define('GROUP_CORD', 		6);
	define('GROUP_FUND', 		10);
	define('GROUP_FREE', 		2);
	define('GROUP_MOD', 		4);
	define('GROUP_SELLER', 		5);
	define('GROUP_VIP', 		12);
        define('GROUP_EXVIP',           14);

	define('FORUM_ROOT', 'https://op7world.net/');
	date_default_timezone_set('America/Sao_Paulo');
	define('TIMENOW', time());
?>