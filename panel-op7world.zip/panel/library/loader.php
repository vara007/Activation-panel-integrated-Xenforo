<?php
include("config.php");
include "library/classes/tools.class.php";
include "library/classes/xenforo.class.php";
include "library/classes/connection.class.php";
include "library/classes/user.class.php";

if(!isset($_SESSION)) session_start();
	session_regenerate_id();
if(empty($_SESSION['user']) && empty($_SESSION['pass'])){
	header('location: login.php');
	exit;
}

$Xenforo       = new Xenforo();
$Tools         = new Tools();
$user_name     = $_SESSION['user'];
$user_pass     = $_SESSION['pass'];

if (!$Xenforo->xf_login($user_name, $user_pass)){
	header('location: login.php');
	exit;
}

$user_avatar_url = $Xenforo->getUser_Avatar($user_name,'s');
$user_session = new User($user_name);
$group_session = $Xenforo->userGroupID($user_name);
require_once("templates/header.php");
require_once("templates/navbar.php");
?>