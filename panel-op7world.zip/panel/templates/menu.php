  <div class="cl-sidebar">
            <div class="cl-toggle"><i class="fa fa-bars"></i>
            </div>
            <div class="cl-navblock">
                <div class="menu-space">
                    <div class="content">
                        <div class="side-user">
                            <div class="avatar"><img src="<?= $user_avatar_url; ?>" alt="Avatar" />
                            </div>
                            <div class="info">
                                <a href="#"><?= $user_name; ?> </a>
                                <img src="images/state_online.png" alt="Status" /> <span>Online</span>
                            </div>
                        </div>
                        <ul class="cl-vnavigation">
                            <li><a href="#"><i class="fa fa-home"></i><span>Dashboard</span></a>
                                <ul class="sub-menu">
                                    <li id="home"><a href="index.php?page=home">Home</a>
                                    </li>
                                </ul>
                            </li>
                         <?php
                            if($group_session == GROUP_ADMIN){
                         ?>
                            <li><a href="#"><i class="fa fa-suitcase"></i><span>Administrator</span></a>
                                <ul class="sub-menu">
                                    <li id="manage-members"><a href="index.php?page=manage_members">Manage Members</a>
                                    </li>
									<li  id="manage-computers"><a href="index.php?page=manage_hwids"> Manage HWIDS</a>
                                    </li>
                                    <li  id="manage-products"><a href="index.php?page=manage_products">Manage Products</a>
                                    </li>
                                     <li  id="reports"><a href="index.php?page=reports"> Reports</a>
                                    </li>
                                </ul>
                            </li>
                        <?php } ?>
                            <li><a href="#"><i class="fa fa-rocket"></i><span>Products</span></a>
                                <ul class="sub-menu">
                                    <li  id="buy-products"><a href="https://op7world.net/forums/ventas-condiciones-de-compra.4/">Buy Products</a>
                                    </li>
                                </ul>
                            </li>
                            <li><a href="#"><i class="fa fa-gears"></i><span>Account</span></a>
                                <ul class="sub-menu">
                                    <li id="member-manage-hwid"><a href="index.php?page=member_manage_hwid">Manage HWID</a>
									 </li>
									<li id="access-log"><a href="index.php?page=access_log">Access Logs</a>
                                    </li>
                                </ul>
                            </li>
                        <?php
                            if($group_session == GROUP_ADMIN || $group_session == GROUP_MOD|| $group_session == GROUP_SELLER){
                         ?>
                            <li><a href="#"><i class="fa fa-gavel"></i><span>Moderation</span></a>
                                <ul class="sub-menu">
                                    <li  id="mod-manage-members"><a href="index.php?page=mod_manage_members">Manage Members</a>
                                    </li>
                                </ul>
                            </li>
                        <?php } ?>
                        </ul>
                    </div>
                </div>
                <div class="text-right collapse-button" style="padding:7px 9px;">
                    <button id="sidebar-collapse" class="btn btn-default" style=""><i style="color:#fff;" class="fa fa-angle-left"></i>
                    </button>
                </div>
            </div>
        </div>