<?php
    require_once("library/loader.php");
?>
<div id="cl-wrapper">
    <?php require_once("templates/menu.php");?>
    <div class="container-fluid" id="pcont">
        <div class="cl-mcont">
<?php
    require_once("library/selection.php");
?>
        </div>
    </div>
</div>

