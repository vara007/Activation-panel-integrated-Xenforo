<?php

//$start_date 	= strtotime(date("d-m-Y H:i:s"));
$end_date 		= 1477692000;
$new_date 		= $end_date - $start_date;
$days 			= intval($new_date / 86400);


echo strtotime("29-11-2016 14:30:30");
//echo $_POST['name'];
//echo $_SERVER['HTTP_REFERER'];
?>