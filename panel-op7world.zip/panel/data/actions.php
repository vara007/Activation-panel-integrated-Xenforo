<?php
if(!isset($_POST['user']) || !isset($_POST['action']))
	die('ERROR_0');
if(empty($_POST['user']) || empty($_POST['action']))
	die('ERROR_1');

define('XF_ROOT', '../..');
include "../includes/config.php";	
include "../includes/classes/xenforo.class.php"; 	
include "../includes/classes/users.class.php";
	
	

	$post_name 		= 			addslashes($_POST['user']);
	$post_action 	= 			addslashes($_POST['action']);
//	$post_status 	= 			addslashes($_POST['status']);	
	
	if($post_action == 'vip-add'){
		//$Users = new CUsers($post_name);
		//$Users->addDaysVIP($post_name,addslashes($_POST['days']));	
		die('VIP_ADD');		
	}

?>